
public class Support {

	String source;
	String target;
	public Support(String source, String target) 
	{
		this.source=source;
		this.target=target;
	}
	

}
